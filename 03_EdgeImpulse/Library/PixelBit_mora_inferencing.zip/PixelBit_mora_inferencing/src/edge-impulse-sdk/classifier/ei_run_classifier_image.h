#ifndef _EDGE_IMPULSE_RUN_CLASSIFIER_IMAGE_H_
#define _EDGE_IMPULSE_RUN_CLASSIFIER_IMAGE_H_

#include "ei_run_classifier.h"



#endif // _EDGE_IMPULSE_RUN_CLASSIFIER_IMAGE_H_
